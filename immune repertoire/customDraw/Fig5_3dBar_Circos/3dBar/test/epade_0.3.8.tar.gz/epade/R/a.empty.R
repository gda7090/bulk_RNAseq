a.empty <-
function(x){
return(x)
}
